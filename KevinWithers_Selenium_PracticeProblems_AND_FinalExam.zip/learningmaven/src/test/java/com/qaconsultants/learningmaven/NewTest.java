package com.qaconsultants.learningmaven;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class NewTest {


@Test
  public void f() {
	 // instantiate a drvier and get the driver from SeleniumHelper class
	//  GetInstance will prevent the user from ever creating more than one instance. Singleton pattern
	  SeleniumHelper sh = SeleniumHelper.GetInstance();
	  
	  WebDriver driver = sh.GetDriver();
	  
	//  navigate browser to test web site
	  driver.get("http://www.automationpractice.com");
	  
	  By loc_searchField = By.id("search_query_top");
	  WebElement searchField = driver.findElement(loc_searchField);
	  
	  searchField.sendKeys("Dress");
	  
	  //Find web element by name for search submit button
	  //Simple
	  By loc_searchButton = By.name("submit_search");
	  WebElement searchButton = driver.findElement(loc_searchButton);
	
	  searchButton.click();
	  
	  
	//Find web element by linkText for Women menu link
	//Simple
//	By loc_womenLink = By.linkText("Women");
	//WebElement womenLink = driver.findElement(loc_womenLink);
	  
	//womenLink.click();
	/*
	SeleniumHelper.Seconds(5);
	SeleniumHelper.MouseHoverByJavaScript(womenLink);
	SeleniumHelper.Seconds(5);
	*/
	//Find web element by ID for selectProductSort drop down menu
	//Simple
	//By loc_selectProductSort = By.id("selectProductSort");
	//WebElement selectProductSort = driver.findElement(loc_selectProductSort);
	
	//SeleniumHelper.Seconds(5);
	
	//Selenium.SelectFromDropDown(selectProductSort, "In Stock");
//	SeleniumHelper.Seconds(5);
	
	
	
	
	
	
	//Find web element by linkText for T-Shirts menu link
	//Simple
	//By loc_tshirtsLink = By.linkText("T-shirts");
	//WebElement tshirtsLink = driver.findElement(loc_tshirtsLink);
	//	List<WebElement> listOfElements = driver.findElements(By.xpath("//a[@linkText = T-shirts]"));
	
	//listOfElements.get(1).click();;
	
	//tshirtsLink.click();

	//Find web element by linkText for Dresses menu link
	//Simple
	By loc_dressesLink = By.linkText("Dresses");
	WebElement dressesLink = driver.findElement(loc_dressesLink);
	
	dressesLink.click();
	
	//Find web element by ID for layered_id_feature_11 "Casual " check box item
	//Simple
	By loc_casualCheckBox = By.id("layered_id_feature_11");
	WebElement casualCheckBox = driver.findElement(loc_casualCheckBox);

	casualCheckBox.click();
	
	
  }
  
  
  
  public void closeSession() {
	  
	  SeleniumHelper.GetInstance().CloseDriver();

  }
 
  
  
  
  
}


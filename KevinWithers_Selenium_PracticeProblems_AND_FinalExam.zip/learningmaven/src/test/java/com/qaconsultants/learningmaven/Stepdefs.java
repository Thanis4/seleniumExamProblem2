package com.qaconsultants.learningmaven;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.MyStoreAddressPage;
import pageObjects.MyStoreCheckPaymentPage;
import pageObjects.MyStoreContactUsPage;
import pageObjects.MyStoreCreateAnAccountPage;
import pageObjects.MyStoreHomePage;
import pageObjects.MyStoreItemAddedToCart;
import pageObjects.MyStoreItemDescriptionPage;
import pageObjects.MyStoreMyAccountPage;
import pageObjects.MyStoreOrderConfirmationPage;
import pageObjects.MyStorePaymentPage;
import pageObjects.MyStoreSearchResultsPage;
import pageObjects.MyStoreShippingPage;
import pageObjects.MyStoreShoppingCartPage;
import pageObjects.MyStoreSignInPage;
import selenium.SeleniumHelper;


public class Stepdefs
		{
			MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
			MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
			MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
			MyStoreMyAccountPage myAccountPage = MyStoreMyAccountPage.GetInstance();
			MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
			//MyStoreSearchResults searchResults = MyStoreSearchResults.GetInstance();
			MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
			MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
			MyStoreItemAddedToCart itemAddedToCartWindow = MyStoreItemAddedToCart.GetInstance();
			MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
			MyStoreAddressPage addressPage = MyStoreAddressPage.GetInstance();
			MyStoreShippingPage shippingPage = MyStoreShippingPage.GetInstance();
			MyStorePaymentPage paymentPage = MyStorePaymentPage.GetInstance();
			MyStoreCheckPaymentPage checkPage = MyStoreCheckPaymentPage.GetInstance();
			MyStoreOrderConfirmationPage orderConfirmation = MyStoreOrderConfirmationPage.GetInstance();
			
			
			
@Given("^user is on homepage$")

public void user_is_on_homepage() throws Exception
			{
				homePage.NavigateToThisPage();
			}
			
@When("^user navigates to signinpage$")	

public void user_navigates_to_signinpage()
	{
		homePage.NavigateToSignInPage();
	}

@When("user begins registration")

public void user_begins_registration()
	{
		signInPage.CreateAnAccount();
	}

@When("user enters default data")
	public void user_enters_default_data()
		{
			createAccountPage.EnterAccountDetails();
		}


@When("user logs out")


public void user_logs_out()
	{
		myAccountPage.SignOut();
	}


@Then("verify signinpage title")
public void verify_signinpage_title()
	{
		signInPage.VerifyTitle();
	}

@When("user signs in")
public void user_signs_in()
	{
		signInPage.SignIn();
	}


@Then("verify myaccountpage title")
public void verify_myaccountpage_title()
	{
		myAccountPage.VerifyTitle();
		}

@When("user navigates to contactuspage")
public void user_navigates_to_contactuspage()
	{
		myAccountPage.NavigateToContactUsPage();
	}

@Then("verify contactuspage title")
public void verify_contactuspage_title()
	{
		contactUsPage.VerifyContactUsHeader();
	}

@When("user enters {string} into search field")	

public void user_enters_text_search_field(String text)
	{
		homePage.SearchText(text);
	}

@When("user clicks submit button on search field")	

public void click_submit_search_field()
	{
		homePage.clickSubmitSearchField();
	}

@Then("verify search results title")	

public void verify_search_results_title()
	{
	searchResultsPage.VerifyTitle();
	}

@When("user searches for {string}")
public void user_searches_for(String string)
	{
		myAccountPage.SearchForItem(string);
		searchResultsPage.SelectItem(string);
	}


@When("user adds item to cart")
public void user_adds_item_to_cart()
	{
		itemDescriptionPage.AddItemToCart();
		SeleniumHelper.Seconds(2);
	}

@When("user continues shopping")
public void user_continues_shopping()
	{
		itemAddedToCartWindow.pressContinueShoppingButton();
		SeleniumHelper.Seconds(2);
	}


@When("user clicks shopping cart")
public void user_clicks_shopping_cart()
	{
		itemDescriptionPage.goToShoppingCart();
	}


@Then("user verifies {string} is in cart")
public void user_verifies_is_in_cart(String string)
	{
		shoppingCartPage.VerifyItemPresenceInCart(string);
	}

@Then("user signs out")
public void user_signs_out()
	{
		shoppingCartPage.SignOut();
	}

// TC 005 - Missing step defs
// create a method for each new step

// While the user is on the HomePage, validae that the home page matches expected result
@Then("user verifies homepage title")
public void user_verifies_homepage_title() {
    
	homePage.VerifyTitle();
	
}


//Create a method where the user validates the Title of the signIn Page
@Then("user verifies signinpage title")
public void user_verifies_signinpage_title() {

	signInPage.VerifyTitle();
	
}


//create a method that will validate the text that is displayed 
@Then("user verifies text {string}")
public void user_verifies_text(String string) {
    //method call to validate if the text is matching on the Add to Cart page
	shoppingCartPage.VerifyTextOnShoppingCartPage(string);
	
}

@Then("user selects color option {string}")
public void user_selects_color_option(String string) {
   //method call to select the blue color option on the search results page
	itemDescriptionPage.selectColorOption(string);
	
	
	
}

@Then("user verifies {string} appears for both items in the Avail column")
public void user_verifies_appears_for_both_items_in_the_column(String string) {

	// method call for validating a string is in one of the columns on the shopping cart check out page
	shoppingCartPage.VerifyInStock(string);
	
	
	
}

@Then("user clicks proceed to checkout")
public void user_clicks_proceed_to_checkout() {
    // Write a method call to click the checkout button on the shopping cart page
	shoppingCartPage.ClickProceedToCheckout();
	
}

@Then("user clicks proceed to checkout on the Address page")
public void user_clicks_proceed_to_checkout_on_the_Address_page() {
    // Write a method that will click the checkout button on the address page
	addressPage.ClickProceedToCheckout();
	
	
}

@Then("user clicks Terms of service checkbox")
public void user_clicks_Terms_of_service_checkbox() {
    // Write a method to click the terms of service checkbox on the shipping page
	shippingPage.ClickTermsOfServiceCheckBox();
	
	
}


@Then("user clicks proceed to checkout on the Shipping page")
public void user_clicks_proceed_to_checkout_on_the_Shipping_page() {
    // Write a method to click the proceed to checkout button on the shipping page
    shippingPage.ClickProceedToCheckout();
    
	
}


@Then("user clicks pay by check button")
public void user_clicks_pay_by_check_button() {
    // Write method to click pay by check on the payment page
    paymentPage.ClickPayByCheck();
    
}

@Then("user verifies {string} is displayed")
public void user_verifies_Check_Payment_is_displayed(String text) {
    // Write method to verify text Check Payment is displayed on the check payment page
	checkPage.VerifyCheckPaymentText(text);
	
}

@Then("user clicks I confirm my order button")
public void user_clicks_I_confirm_my_order_button() {
    // Write a method to click the confirm order button on the check page
    checkPage.ClickConfirmOrder();
    
    
}

@Then("user verifies text displayed {string}")
public void user_verifies_text_displayed(String string) {
    // Write a method to validate the string is on the order confirmation page
	orderConfirmation.VerifyText(string);
	
}


}
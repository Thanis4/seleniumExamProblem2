package pageObjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import selenium.Selenium;
import selenium.SeleniumHelper;


public class MyStoreShoppingCartPage extends MyStorePageObject
{
		private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
		private static MyStoreShoppingCartPage m_instance;
		
		@FindBy(xpath = "//*[@class = 'cart_avail']")
		List<WebElement> cartAvail;
		
		@FindBy(xpath = "//span[@class = 'label label-success']")
		List<WebElement> labels;
		
		@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
		List<WebElement> checkoutButtons;
		
		@FindBy(id = "cart_summary")
		WebElement tblCartSummary;
		
	
		
		
private MyStoreShoppingCartPage(WebDriver _driver)
{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
}


public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName)
{
		log.debug("Verifying item presence in the cart");

		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName))
		{
			log.info("The item " + _itemName + " was successfully found in cart");
		}
		else
		{
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
}







//Create a new method to validate that the text on the Add to cart window is displaying as expeceted when a product is added successfully.

public MyStoreShoppingCartPage VerifyTextOnShoppingCartPage(String _text) {
	
	log.debug("Verifying the text on the Shopping Cart page is matching expected result");
	
	if(SeleniumHelper.VerifyTextPresentOnPage("Product successfully added to your shopping cart")) {
		
			log.info("The text " + _text + "  was successfully found");
			
	}else {
		
			log.info("The text " + _text + "  was NOT found");
	}
	return MyStoreShoppingCartPage.GetInstance();
	
	
}




public void VerifyInStock(String string) {
	
	String lblColor = "rgba(85, 198, 94, 1)";
	
	List<WebElement> rowVals = tblCartSummary.findElements(By.tagName("tr"));
	
	for(int i =0; i < rowVals.size(); i++) {
		
			List<WebElement> tdVals = rowVals.get(i).findElements(By.className("cart_avail"));
			
			//loop through all the table cells that are in the Available column
				for(int j = 1; j < tdVals.size(); j ++) {
					
					//validate that the In stock label is in the avail' table cell
					Assert.assertEquals(tdVals.get(j).getText(), string);
					
					System.out.println("The TD element in the Avail column is " + tdVals.get(j).getText());
					
				}
			
		
	}
	
		
		//Loop through the labels 
		for(WebElement label : labels) {
			
			//Validate that the label contains the expected spelling of In Stock
			Selenium.VerifyTextInElement(label, string);
			
			//get the color of the label
			String color = label.getCssValue("background-color");
			//validate that the label matches the expected color
			Assert.assertEquals(color, lblColor);
			
			//debugging println statement
			System.out.println("Color of the label is: " + color);
			
		}
	//}
	
	
	
}


public static MyStoreShoppingCartPage GetInstance()
{
	if (m_instance == null)
	{
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
	}
	return m_instance;
}


public MyStoreAddressPage ClickProceedToCheckout() {
	
	WebElement checkoutBtn = checkoutButtons.get(1);
	
	checkoutBtn.click();
	
	return MyStoreAddressPage.GetInstance();
	
		
}




}


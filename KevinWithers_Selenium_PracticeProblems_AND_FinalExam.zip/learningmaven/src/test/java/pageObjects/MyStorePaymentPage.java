package pageObjects;


import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;


public class MyStorePaymentPage extends MyStorePageObject{


	private static final Logger log = LogManager.getLogger(MyStorePaymentPage.class);
	private static MyStorePaymentPage m_instance;
	
	
	
	@FindBy(xpath = "//a[@title = 'Pay by check.']")
	WebElement btnPayByCheck;
	
	
	
	private MyStorePaymentPage(WebDriver _driver) {
		
		log.debug("You are on the Address Page Now");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	
	public static MyStorePaymentPage GetInstance()
	{
	if (m_instance == null)
		{
			m_instance = new MyStorePaymentPage(SeleniumHelper.GetInstance().GetDriver());

		}
	
		return m_instance;
	}


	public MyStoreCheckPaymentPage ClickPayByCheck() {
		//Click the PayByCheck button
		
		
		btnPayByCheck.click();
		return MyStoreCheckPaymentPage.GetInstance();
		
		
		
	}
	
	
	
	
	
}

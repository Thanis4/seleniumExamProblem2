package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import selenium.Selenium;
import selenium.SeleniumHelper;



public class MyStoreOrderConfirmationPage {
	
	
	private static final Logger log = LogManager.getLogger(MyStoreOrderConfirmationPage.class);
	private static MyStoreOrderConfirmationPage m_instance;

	
	
	private MyStoreOrderConfirmationPage(WebDriver _driver) {
		
		log.debug("You are on the Order Confirmation Page Now");
		
		PageFactory.initElements(_driver, this);
		
	}
	
	
	
	public static MyStoreOrderConfirmationPage GetInstance()
	{
	if (m_instance == null)
		{
			m_instance = new MyStoreOrderConfirmationPage(SeleniumHelper.GetInstance().GetDriver());

		}
	
		return m_instance;
	}



	public void VerifyText(String string) {
		//Verify if the text is on the page
				boolean onPage = SeleniumHelper.VerifyTextPresentOnPage(string);
				
				//If True it will pass, otherwise it will fail
				Assert.assertTrue(onPage);
				//Assert.assertEquals(text, "Check Payment");
				
	}


	
	
}

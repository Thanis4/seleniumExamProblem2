package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShippingPage extends MyStorePageObject{

	private static final Logger log = LogManager.getLogger(MyStoreItemDescriptionPage.class);
	private static MyStoreShippingPage m_instance;
	
	
	@FindBy(id = "cgv")
	WebElement termsCheckBox;
	
	@FindBy(name = "processCarrier")
	WebElement proceedToCheckOut;
	
	
	
	
private MyStoreShippingPage(WebDriver _driver) {
	
	log.debug("Going to the Shipping Page");
	m_pageTitle = "Order - My Store";
	PageFactory.initElements(_driver, this);
	
	
}
	

public void ClickTermsOfServiceCheckBox() {
	
	
		termsCheckBox.click();
		
}


public MyStorePaymentPage ClickProceedToCheckout() {
	
	proceedToCheckOut.click();
	
	return MyStorePaymentPage.GetInstance();
	
}

public static MyStoreShippingPage GetInstance()
{
if (m_instance == null)
	{
		m_instance = new MyStoreShippingPage(SeleniumHelper.GetInstance().GetDriver());

	}

	return m_instance;
}



	
}

package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import selenium.Selenium;
import selenium.SeleniumHelper;


public class MyStoreCheckPaymentPage extends MyStorePageObject {
	
	private static final Logger log = LogManager.getLogger(MyStoreCheckPaymentPage.class);
	private static MyStoreCheckPaymentPage m_instance;
	
	
	@FindBy(xpath= ("//*[@class = 'button btn btn-default button-medium']"))
	WebElement btnConfirm;
	
	
	
	
	private MyStoreCheckPaymentPage(WebDriver _driver) {
				
		log.debug("You are on the Check Payment Page Now");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
		
	}
	
	
	public void VerifyCheckPaymentText(String text) {
		
		//Verify if the text is on the page
		boolean onPage = SeleniumHelper.VerifyTextPresentOnPage("Check payment");
		
		//If True it will pass, otherwise it will fail
		Assert.assertTrue(onPage);
		//Assert.assertEquals(text, "Check Payment");
		
		
		
	}


	public MyStoreOrderConfirmationPage ClickConfirmOrder() {
		//Click the confirm button
		Selenium.Click(btnConfirm);
		
		return MyStoreOrderConfirmationPage.GetInstance();
		
		
	}

	public static MyStoreCheckPaymentPage GetInstance()
	{
	if (m_instance == null)
		{
			m_instance = new MyStoreCheckPaymentPage(SeleniumHelper.GetInstance().GetDriver());

		}
	
		return m_instance;
	}


}

package pageObjects;


import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;



public class MyStoreAddressPage extends MyStorePageObject {

	
	
	private static final Logger log = LogManager.getLogger(MyStoreAddressPage.class);
	private static MyStoreAddressPage m_instance;
	
	
	@FindBy(name = "processAddress")
	WebElement processAddressBtn;
	
	
	
	
	
	
	//Constructor to set the page title and instantiate the pageFactory elements from webdriver
	private MyStoreAddressPage(WebDriver _driver) {
		
		log.debug("You are on the Address Page Now");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
		
	}
	
	
	//Method to click the Proceed to checkout button which goes to the shipping page
	
	public MyStoreShippingPage ClickProceedToCheckout() {
		
		
		processAddressBtn.click();
		
		return MyStoreShippingPage.GetInstance();
		
	}	
	
	
	
	
	public static MyStoreAddressPage GetInstance()
	{
	if (m_instance == null)
		{
			m_instance = new MyStoreAddressPage(SeleniumHelper.GetInstance().GetDriver());

		}
	
		return m_instance;
	}

	
	
	
	
}

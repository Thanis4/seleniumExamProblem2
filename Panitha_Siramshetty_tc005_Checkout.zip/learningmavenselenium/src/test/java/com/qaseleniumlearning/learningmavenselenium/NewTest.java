package com.qaseleniumlearning.learningmavenselenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import selenium.SeleniumHelper;

public class NewTest {
  @Test
 
  
		  public void f() {
		  	  
		  	   SeleniumHelper sh = SeleniumHelper.GetInstance();
		  	  // WebDriver driver = SeleniumHelper.GetInstance().GetDriver(); - the other way 
		  	   		  	 		  	   
		  	   WebDriver driver = sh.GetDriver();
		  	   driver.get("http://www.automationpractice.com");
		  	   
		  	   System.out.println(driver.getTitle());
		  	  //System.out.println(driver.getPageSource());
		  	   
		  	  //SeleniumHelper.GetInstance().CloseDriver(); - the other way
		  	/* By loc_searchField = By.name("q"); 
		  	WebElement SearchField = driver.findElement(loc_searchField);
		  	SearchField.sendKeys("Pluralsight");
		  	SearchField.submit();
		    SeleniumHelper.Seconds(5);
		  	sh.CloseDriver();*/
		  	
		  	
		  	
		  	By loc_dresses = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a"); 
		    WebElement dresses = driver.findElement(loc_dresses);
		    dresses.click();
		    
		    By loc_dressesImage = By.xpath("//div[@class='content_scene_cat_bg']"); 
		    WebElement dressesImage = driver.findElement(loc_dressesImage);
		   boolean display = dressesImage.isDisplayed();
	  	System.out.println(display);
		    
		    By loc_addCart = By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[1]/span"); 
		    WebElement addCart = driver.findElement(loc_addCart);
		    addCart.click();
		    
		   // By loc_continueShopping = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/span/span"); 
		    //WebElement continueShopping = driver.findElement(loc_continueShopping);
		    //continueShopping.click();
		    
		   //By loc_close = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[1]/span"); 
		    // By loc_close = By.xpath(" //span[@title='Close window']");
		   // WebElement close = driver.findElement(loc_close);
		    //span[@title="Close window"]
		   // close.click();

		  	

		  	   
		  	   
  }
}

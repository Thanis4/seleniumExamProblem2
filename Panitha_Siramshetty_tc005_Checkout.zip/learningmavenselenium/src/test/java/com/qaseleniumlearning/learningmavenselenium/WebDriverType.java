package com.qaseleniumlearning.learningmavenselenium;

public enum WebDriverType {
	CHROME, FIREFOX, EDGE

}

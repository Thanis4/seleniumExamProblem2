package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreSearchResultsPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreSearchResultsPage m_instance;

	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;
	@FindBy(id = "search_query_top")
	WebElement searchBox;
	@FindBy(name = "submit_search")
	WebElement searchIcon;
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1/span[2]")
	WebElement searchResult;

	private MyStoreSearchResultsPage(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	// public MyStoreSearchItem SearchforFadedshirt()
	public MyStoreItemDescriptionPage SearchforItem(String itemName)
	{
		log.debug("Search for Faded Short Sleeve T-Shirt on Home page");
		Selenium.Input(searchBox, itemName);
		Selenium.Click(searchIcon);
		SeleniumHelper.Seconds(3);
		return MyStoreItemDescriptionPage.GetInstance();
	}

	public MyStoreItemDescriptionPage SelectItem(String _itemName)
	{
		log.debug("Selecting the item from Search Results");
		WebElement searchItem = SeleniumHelper.FindElement(By.linkText(_itemName));
		Selenium.Click(searchItem);
		SeleniumHelper.VerifyPageTitle(_itemName + " - My Store");

		return MyStoreItemDescriptionPage.GetInstance();
	}
	/*
	 * 
	 * public MyStoreSearchItem SearchResult() {
	 * log.debug("Search results  displayed");
	 * 
	 * Selenium.VerifyTextInElement(searchResult, "results have been found");
	 * 
	 * return MyStoreSearchItem.GetInstance(); }
	 */

	public static MyStoreSearchResultsPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreSearchResultsPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void TriggerAssert() throws AssertionError
	{
		throw new AssertionError("This should FAIL");
	}
}

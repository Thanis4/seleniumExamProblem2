package pageobjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreItemDescriptionPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreItemDescriptionPage m_instance;

	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;
	@FindBy(id = "search_query_top")
	WebElement searchBox;
	@FindBy(name = "submit_search")
	WebElement searchIcon;
	// @FindBy(xpath = "//*[@id=\"add_to_cart\"]/button/span")
	@FindBy(name = "Submit")
	WebElement AddToCart;
	@FindBy(xpath = "//a[@title='View my shopping cart']")
	WebElement goToShoppingCart;

	@FindBy(id = "color_14")
	WebElement selectColour;
	@FindBy(xpath = "//span[@class='label label-success']")
	WebElement inStock;

	private MyStoreItemDescriptionPage(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreItemAddedToCartWindow AddItemToCart()
	{
		log.debug("Add Item to cart");
		Selenium.Click(AddToCart);
		SeleniumHelper.Seconds(3);
		// Selenium.VerifyTextInElement(_xpath, _"//*[@id="center_column"]/h1/span[2]");
		return MyStoreItemAddedToCartWindow.GetInstance();
	}

	public MyStoreShoppingCartPage goToShoppingCart()
	{
		log.debug("verify the shopping cart");
		Selenium.Click(goToShoppingCart);
		SeleniumHelper.Seconds(3);
		SeleniumHelper.VerifyTextPresentOnPage("Product successfully added to your shopping cart");
		return MyStoreShoppingCartPage.GetInstance();
	}

	public MyStoreShoppingCartPage selectColour()
	{
		log.debug("Select the colour option");
		Selenium.Click(selectColour);
		System.out.println("Blue colour selected for 2nd item");
		Selenium.Click(AddToCart);
		SeleniumHelper.Seconds(3);
		return MyStoreShoppingCartPage.GetInstance();
	}

	public MyStoreShoppingCartPage item_Instock()
	{
		log.debug("Verify  InStock appears in Avail. column");
		List<WebElement> instocks = SeleniumHelper.FindElements(By.xpath("//span[@class='label label-success']"));
		if (instocks.size() == 2)
		{

			System.out.println("2 In _Stock items are present");
		} else
		{
			System.out.println("2 In _Stock items  are not present");
		}

		SeleniumHelper.Seconds(10);
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreItemDescriptionPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreItemDescriptionPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
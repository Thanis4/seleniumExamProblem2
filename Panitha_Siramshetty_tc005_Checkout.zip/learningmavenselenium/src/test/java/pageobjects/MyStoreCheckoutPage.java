package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCheckoutPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreCheckoutPage m_instance;

	@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]/span")
	WebElement proceedToCheckout1;

	@FindBy(name = "processAddress")
	WebElement proceedToCheckout2;

	@FindBy(xpath = "//input[@id=\"cgv\"]")
	WebElement termsOfService;

	@FindBy(xpath = "//button[@class = 'button btn btn-default standard-checkout button-medium']")
	WebElement proceedToCheckout3;

	private MyStoreCheckoutPage(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreCheckoutPage ProceedToCheckout()
	{
		log.debug("Verify Proceed to Checkout");
		Selenium.Click(proceedToCheckout1);
		SeleniumHelper.Seconds(3);
		Selenium.Click(proceedToCheckout2);
		return MyStoreCheckoutPage.GetInstance();
	}

	public MyStoreCheckoutPage TermsOfService()
	{
		log.debug("Select Terms of Service");
		// termsOfService.click();
		Selenium.ToggleCheckBox(By.xpath("//input[@id=\"cgv\"]"));
		SeleniumHelper.Seconds(3);
		Selenium.Click(proceedToCheckout3);
		SeleniumHelper.Seconds(3);
		return MyStoreCheckoutPage.GetInstance();
	}

	public static MyStoreCheckoutPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreCheckoutPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
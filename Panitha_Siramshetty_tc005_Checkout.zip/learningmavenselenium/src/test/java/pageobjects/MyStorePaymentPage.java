package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStorePaymentPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStorePaymentPage m_instance;

	// @FindBy(xpath = "//a[contains(text() , 'Pay by check')]")
	@FindBy(xpath = "//a[@class='cheque']")
	WebElement payByCheck;
	@FindBy(xpath = "//*[@id='cart_navigation']/button")
	WebElement myOrder_Confirmation;

	private MyStorePaymentPage(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStorePaymentPage payByCheck()
	{
		log.debug("Selecting Pay by Check");
		Selenium.Click(payByCheck);
		SeleniumHelper.Seconds(3);
		return MyStorePaymentPage.GetInstance();
	}

	public MyStorePaymentPage checkPayment()
	{
		log.debug("Verify CHECK PAYMENT");
		String expText = "Check payment";
		SeleniumHelper.Seconds(3);
		if (SeleniumHelper.VerifyTextPresentOnPage(expText))
		{
			log.info("CHECK PAYMENT is displayed");
			System.out.println("CHECK PAYMENT is displayed");
		} else
		{
			log.error("CHECK PAYMENT not displayed");
			System.out.println("CHECK PAYMENT is not displayed");
		}
		return MyStorePaymentPage.GetInstance();

	}

	public MyStorePaymentPage confirmMyOrder()
	{
		log.debug("Selecting Order Confirmation");
		Selenium.Click(myOrder_Confirmation);
		System.out.println("My Order placed");
		SeleniumHelper.Seconds(3);
		return MyStorePaymentPage.GetInstance();
	}

	public MyStorePaymentPage orderConfirmation()
	{
		log.debug("Order Confirmation is displayed");
		String expText = "Your order on My Store is complete.";
		if (SeleniumHelper.VerifyTextPresentOnPage(expText))
		{
			log.info("Order Placement is Successful");
			System.out.println("Order Placement is Successful");
		} else
		{
			log.error("Order Placement is not Successful");
			System.out.println("Order Placement is not Successful");
		}
		SeleniumHelper.Seconds(3);
		return MyStorePaymentPage.GetInstance();

	}

	public static MyStorePaymentPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStorePaymentPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}

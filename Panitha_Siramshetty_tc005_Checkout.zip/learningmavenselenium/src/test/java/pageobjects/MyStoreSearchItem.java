package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreSearchItem extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreSearchItem.class);
	private static MyStoreSearchItem m_instance;

	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;
	@FindBy(id = "search_query_top")
	WebElement searchBox;
	@FindBy(name = "submit_search")
	WebElement searchIcon;
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1/span[2]")
	WebElement searchResult;

	// @FindBy(xpath = "//*[@id=\"center_column\"]/h1/span[2]")

	private MyStoreSearchItem(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreSearchItem SearchForDresses()
	{
		log.debug("Search for dresses on Home page");
		Selenium.Input(searchBox, "Dresses");
		Selenium.Click(searchIcon);
		SeleniumHelper.Seconds(3);

		// Selenium.VerifyTextInElement(_xpath, _"//*[@id="center_column"]/h1/span[2]");

//Selenium.Click(contactUsButton);
		return MyStoreSearchItem.GetInstance();
	}

	public MyStoreSearchItem SearchResult()
	{
		log.debug("Search results  displayed");

		Selenium.VerifyTextInElement(searchResult, "results have been found");

		return MyStoreSearchItem.GetInstance();
	}

	public static MyStoreSearchItem GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreSearchItem(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void TriggerAssert() throws AssertionError
	{
		throw new AssertionError("This should FAIL");
	}
}

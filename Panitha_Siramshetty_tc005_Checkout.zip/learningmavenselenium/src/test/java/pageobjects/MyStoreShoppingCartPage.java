package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreShoppingCartPage m_instance;

	WebElement AddToCart;
	@FindBy(xpath = "//a[@title='View my shopping cart']")
	WebElement gotoShoppingCart;
	@FindBy(xpath = "//span[@class='continue btn btn-default button exclusive-medium']")
	WebElement ContinueShopping;

	private MyStoreShoppingCartPage(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String itemName)
	{
		// log.debug("Verify Item Description");
		// not Selenium.Click(ContinueShopping);
		// SeleniumHelper.VerifyTextPresentOnPage(itemName);
		// SeleniumHelper.Seconds(3);
		// return MyStoreShoppingCartPage.GetInstance();
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(itemName))
		{
			// log.info("The item " + _itemName + " was successfully found in cart");
			System.out.println("The item " + itemName + " was successfully found in cart");

		} else
		{
			// log.error("The item " + _itemName + " was NOT found in cart");
			System.out.println("The item " + itemName + " was successfully NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreShoppingCartPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
package selenium;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import selenium.SeleniumHelper;

public class NewTest {
	@Test
		
		public void f() {
			  
			   SeleniumHelper sh = SeleniumHelper.GetInstance();
			   
			  // SeleniumHelper sh2 = SeleniumHelper.GetInstance();
			   
			   WebDriver driver = sh.GetDriver();
			   
			   //driver.get("http://google.ca");
			   
			   driver.get("http://automationpractice.com");
			   
			    System.out.println(driver.getTitle());
			    
			    By loc_dresses = By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a"); 
			    WebElement dresses = driver.findElement(loc_dresses);
			    dresses.click();
			    
			    By loc_addCart = By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[1]/span"); 
			    WebElement addCart = driver.findElement(loc_addCart);
			    addCart.click();
			    
			    driver.switchTo().alert().dismiss(); 
			    
			  // By loc_close = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[1]/span"); 
			   // WebElement close = driver.findElement(loc_close);
			    //close.click();
			  
			   // By loc_removeItem= By.xpath("//*[@href='http://automationpractice.com/index.php?controller=cart&amp;delete=1&amp;id_product=3&amp;token=e817bb0705dd58da8db074c69f729fd8&amp;ipa=13']"); 
			  //  WebElement removeItem = driver.findElement(loc_removeItem);
			    //removeItem.click();
			    
			  
			    
			    System.out.println(driver.getTitle());
			  
			   // System.out.println(driver.getPageSource());
			   
			   
			   SeleniumHelper.Seconds(10);
			   
			   SeleniumHelper.GetInstance().CloseDriver();
		  } 
		 
		

}

package pageobjects;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;
public class MyStoreItemSearch extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreItemSearch.class);
private static MyStoreItemSearch m_instance;
private String m_url;
@FindBy(id = "search_query_top")
WebElement searchBox;
@FindBy(xpath = "//*[@id=\"searchbox\"]/button")
WebElement searchIcon;
@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/h5/a")
WebElement result;
@FindBy(name = "Submit")  
WebElement addToCart;
@FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/span/span")  
WebElement continueShopping;
@FindBy(xpath = "//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a")  
WebElement cart;

private MyStoreItemSearch(WebDriver _driver)
{
log.debug("creating Home Page PageObject");
m_url = "http://automationpractice.com/index.php";
m_pageTitle = "My Store";
PageFactory.initElements(_driver, this);
}
public MyStoreItemSearch NavigateToThisPage()
{
SeleniumHelper.Get(m_url);
return GetInstance();
}
public static MyStoreItemSearch GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStoreItemSearch(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}
public void TriggerAssert() throws AssertionError
{
throw new AssertionError("This should FAIL");
}
public MyStoreItemSearch SearchItemName(String itemName)
{
log.debug("entering item name");
Selenium.Input(searchBox, itemName);
Selenium.Click(searchIcon);
return MyStoreItemSearch.GetInstance();
}

public MyStoreItemSearch SelectItem(String itemName)
{
	WebElement selectItem = SeleniumHelper.FindElement(By.linkText(itemName));
	Selenium.Click(selectItem);
	return MyStoreItemSearch.GetInstance();
}

public MyStoreItemSearch AddToCart()
{
	Selenium.Click(addToCart);
	return MyStoreItemSearch.GetInstance();
}

public MyStoreItemSearch ContinueShopping()
{
	Selenium.Click(continueShopping);
	return MyStoreItemSearch.GetInstance();
}

public MyStoreItemSearch GoToShoppingCart()
{
	Selenium.Click(cart);
	SeleniumHelper.Seconds(3);
	return MyStoreItemSearch.GetInstance();
}

public MyStoreItemSearch VerifyItemsInCart(String itemName)
{
	SeleniumHelper.VerifyTextPresentOnPage(itemName);
	SeleniumHelper.Seconds(3);
	return MyStoreItemSearch.GetInstance();
}

}
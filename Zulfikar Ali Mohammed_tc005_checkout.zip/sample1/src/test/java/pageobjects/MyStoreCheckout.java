package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCheckout extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreCheckout.class);
private static MyStoreCheckout m_instance;
@FindBy(id = "color_14")
WebElement colourButton;
@FindBy(xpath = "//*[contains(@class,'cart_item first_item address')]/td[3]/span")  
WebElement inStock1;
@FindBy(xpath = "//*[contains(@class,'cart_item last_item address')]/td[3]/span")  
WebElement inStock2;
@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]")  
WebElement proceed1;
@FindBy(xpath = "//*[@id=\"center_column\"]/form/p/button")  
WebElement proceed2;
@FindBy(xpath = "//*[@id=\"form\"]/p/button")  
WebElement proceed3;
@FindBy(id = "cgv")  
WebElement checkBox;
@FindBy (xpath = "//*[@id=\"HOOK_PAYMENT\"]/div[2]/div/p")
WebElement payByCheck;
@FindBy (xpath ="//*[@id=\"cart_navigation\"]/button")
WebElement confirmOrder;

private MyStoreCheckout(WebDriver _driver)
{
log.debug("creating Home Page PageObject");
m_pageTitle = "My Store";
PageFactory.initElements(_driver, this);
}

public MyStoreCheckout Clickblue(String colour)
{
log.debug("selecting blue ");
Selenium.Click(colourButton);
System.out.println("Selected colour blue");
SeleniumHelper.Seconds(3);
return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Instock()
{
		String s1 = inStock1.getText();
		String s2 = inStock2.getText();
		if (s1.equalsIgnoreCase("In stock"))
			System.out.println("Printed Summer Dress is in stock");
		if (s2.equalsIgnoreCase("In stock"))
			System.out.println("Blue Faded short sleeve T-shirt is in stock");
	return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Proceed1()
{
		Selenium.Click(proceed1);
		SeleniumHelper.Seconds(1);
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Proceed2()
{
		Selenium.Click(proceed2);
		SeleniumHelper.Seconds(1);
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Proceed3()
{		
	Selenium.Click(proceed3);
	SeleniumHelper.Seconds(1);
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Verifyaddress()
{
	if(	SeleniumHelper.VerifyTextPresentOnPage("Addresses"));
		System.out.println("Address page is displayed");
	
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Verifyshipping()
{
	if(	SeleniumHelper.VerifyTextPresentOnPage("Shipping"));
		System.out.println("Shipping page is displayed");
	
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Verifypayment()
{
	if(	SeleniumHelper.VerifyTextPresentOnPage("Please choose your payment method"));
		System.out.println("Payment page is displayed");
	
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Checkbox()
{
		Selenium.Click(checkBox);
		return MyStoreCheckout.GetInstance();
}

public MyStoreCheckout Checkpayment()
{
	if(	SeleniumHelper.VerifyTextPresentOnPage("Check payment"));
		System.out.println("Check Payment page is displayed");
	
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout ClickPayByCheck()
{		
	Selenium.Click(payByCheck);
		return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Confirmorder()
{		
	Selenium.Click(confirmOrder);
	return MyStoreCheckout.GetInstance();
}
public MyStoreCheckout Ordercomplete()
{
	if(	SeleniumHelper.VerifyTextPresentOnPage("Your order on My Store is complete."));
		System.out.println("Order is completed");
	
		return MyStoreCheckout.GetInstance();
}
public static MyStoreCheckout GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStoreCheckout(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}
}

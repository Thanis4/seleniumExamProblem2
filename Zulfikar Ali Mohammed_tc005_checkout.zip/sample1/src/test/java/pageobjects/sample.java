package pageobjects;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;
public class sample extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreItemSearch.class);
private static sample m_instance;
private String m_url;
@FindBy(id = "search_query_top")
WebElement searchBox;
@FindBy(xpath = "//*[@id=\"searchbox\"]/button")
WebElement searchIcon;
@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/h5/a")
WebElement result;
@FindBy(xpath = "//*[@id=\"add_to_cart\"]/button/span")
WebElement addToCart;
@FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/span/span")
WebElement continueShopping;
private sample(WebDriver _driver)
{
log.debug("creating Home Page PageObject");
m_url = "http://automationpractice.com/index.php";
m_pageTitle = "My Store";
PageFactory.initElements(_driver, this);
}
public sample NavigateToThisPage()
{
SeleniumHelper.Get(m_url);
return GetInstance();
}
public static sample GetInstance()
{
if (m_instance == null)
{
m_instance = new sample(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}
public void TriggerAssert() throws AssertionError
{
throw new AssertionError("This should FAIL");
}



	  
public String[] items = new String[]{"Faded Short Sleeve T-shirts", "Blouse", "Printed Dress"}; 
 
	 
public sample EnterItemName()
{
  for(int i=0; i<3; i++) 
  {
   log.debug("entering item name");
   Selenium.Input(searchBox, items[i]);
   Selenium.Click(searchIcon);
  }

	if (m_instance == null)
		return sample.GetInstance();
		else
		return null;
}
 
 
public sample GiveResult()
{
	for(int i=0; i<3; i++)
	{
		SeleniumHelper.VerifyTextPresentOnPage(items[i]);
		SeleniumHelper.Seconds(5);
	}
	return sample.GetInstance();
}


public MyStoreItemSearch AddToCart()
{
	Selenium.Click(addToCart);
	return null;
}

public MyStoreItemSearch ContinueShopping()
{
	Selenium.Click(continueShopping);
	return null;
}


/*public static By GetXpathFromElementContainingText(String text, String
		tagName)
		{
		if (tagName.isEmpty())
		{
		tagName = "*";
		}
		//// tagName[contains(text(), 'textInElement')]
		String selectorString = "Printed Chiffon Dress" + tagName + "[contains(text(), '" +
		text + "')]";
		return By.xpath(selectorString);
		}*/
}
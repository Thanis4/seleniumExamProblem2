package com.tdseleniumtwo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreCheckout;
import pageobjects.MyStoreContactUsPage;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStorePageObject;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;
import pageobjects.MyStoreItemSearch;
public class Stepdefs
{
MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
MyStoreMyAccountPage myAccoutnPage = MyStoreMyAccountPage.GetInstance();
MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
MyStoreItemSearch searchItem = MyStoreItemSearch.GetInstance();
MyStorePageObject signOut = MyStorePageObject.GetInstance();
MyStoreCheckout checkOut = MyStoreCheckout.GetInstance();

@Given("^user is on homepage$")
public void user_is_on_homepage() throws Exception
{
homePage.NavigateToThisPage();
}
@When("^user navigates to signinpage$")
public void user_navigates_to_signinpage()
{
homePage.NavigateToSignInPage();
}
@When("user begins registration")
public void user_begins_registration()
{
signInPage.CreateAnAccount();
}
@When("user enters default data")
public void user_enters_default_data()
{
createAccountPage.EnterAccountDetails();
}
@When("user logs out")
public void user_logs_out()
{
myAccoutnPage.SignOut();
}
@Then("verify signinpage title")
public void verify_signinpage_title()
{
signInPage.VerifyTitle();
}
@When("user signs in")
public void user_signs_in()
{
signInPage.SignIn();
}
@Then("verify myaccountpage title")
public void verify_myaccountpage_title()
{
myAccoutnPage.VerifyTitle();
}
@When("user navigates to contactuspage")
public void user_navigates_to_contactuspage()
{
myAccoutnPage.NavigateToContactUsPage();
}
@Then("verify contactuspage title")
public void verify_contactuspage_title()
{
contactUsPage.VerifyTitle();
}

@When("user searches for {string}")
public void user_searches_for(String string) {
    searchItem.SearchItemName(string);
	SeleniumHelper.Seconds(2);
    searchItem.SelectItem(string);
}

@When("user clicks on add to cart")
public void user_clicks_on_add_to_cart() {
	searchItem.AddToCart();
}

@When("user clicks on continue shopping")
public void user_clicks_on_continue_shopping() {
   searchItem.ContinueShopping();
}

@When("user clicks on Shopping cart")
public void user_clicks_on_Shopping_cart() {
	searchItem.GoToShoppingCart();
}

@Then("verify item in cart {string}")
public void verify_item_in_cart(String string) {
	searchItem.VerifyItemsInCart(string);
}
@When("user selects colour {string}")
public void user_selects_colour(String string) {
	checkOut.Clickblue(string);
}

@Then("verify that in stock appears for items in avail column")
public void verify_that_appears_for_items_in_column() {
  checkOut.Instock();
}

@When("user clicks on Proceed to checkout first button")
public void user_clicks_on_Proceed_to_checkout_first_button() {
	checkOut.Proceed1();
    
}

@When("user clicks on Proceed to checkout second button")
public void user_clicks_on_Proceed_to_checkout_second_button() {
	checkOut.Proceed2();
}

@When("user clicks on Proceed to checkout third button")
public void user_clicks_on_Proceed_to_checkout_third_button() {
	checkOut.Proceed3();
}

@When("user clicks on Pay by check button")
public void user_clicks_on_button() {
   checkOut.ClickPayByCheck();
}

@Then("verify Address section")
public void verify_Address_section() {
   checkOut.Verifyaddress();
}

@Then("verify Shipping section")
public void verify_Shipping_section() {
   checkOut.Verifyshipping();
}

@When("user clicks on terms of service checkbox")
public void user_clicks_on_terms_of_service_checkbox() {
	checkOut.Checkbox();
}

@Then("verify Payment section")
public void verify_Payment_section() {
  checkOut.Verifypayment();
}

@Then("verify that CHECK PAYMENT is displayed")
public void verify_that_CHECK_PAYMENT_is_displayed() {
    checkOut.Checkpayment();
}

@When("user clicks on I confirm my order button")
public void user_clicks_on_I_confirm_my_order_button() {
   checkOut.Confirmorder();
}

@Then("verify Your order on My Store is complete is displayed")
public void verify_Your_order_on_My_Store_is_complete_is_displayed() {
    checkOut.Ordercomplete();
}

@Then("user signs out")
public void user_signs_out() {
  signOut.SignOut();
}
}

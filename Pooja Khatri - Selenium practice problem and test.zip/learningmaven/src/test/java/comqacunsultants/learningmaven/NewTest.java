package comqacunsultants.learningmaven;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import selenium.SeleniumHelper;
public class NewTest {
 //@Test
  public void f() {
	  // to open web browser//
	  WebDriver driver = SeleniumHelper.GetInstance().GetDriver();
	  // to open Url//
	  driver.get("http://www.automationpractice.com");
  }
}

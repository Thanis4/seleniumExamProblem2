package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreItemDescriptionPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreItemDescriptionPage.class);
	private static MyStoreItemDescriptionPage m_instance;
	@FindBy(name = "Submit")
	WebElement addToCartButton;
	@FindBy(xpath = "//a[@title = 'View my shopping cart']")
	WebElement cartLink;
	@FindBy(id = "cart_title")
	WebElement cartPageTitle;
	@FindBy(xpath = "//a[@title='View my customer account']")
	WebElement customerNameLink;

	//Venkata's code for exam
	@FindBy(css = "#color_14")
	WebElement blueColorLink;
	
	@FindBy(xpath = "//*[@id=\'layer_cart\']/div[1]/div[2]/div[4]/a/span")
	WebElement checkoutButtonPopUp;
	
	@FindBy(xpath = "//*[@id=\'product_5_19_0_181441\']/td[3]/span")
	WebElement printedSummerDressInStock;
	
	@FindBy(xpath = "//*[@id=\'product_1_2_0_181441\']/td[3]/span")
	WebElement fadedshortsleevetshirtInStock;
	
	@FindBy(linkText = "Proceed to checkout")
	WebElement proceedToCheckoutSummaryPage;
	
	@FindBy(xpath = "//*[@id=\'center_column\']/form/p/button/span")
	WebElement proceedToCheckoutAddressPage;
	
	@FindBy(id = "cgv")
	WebElement checkBox;
	
	@FindBy(xpath = "//*[@id=\"form\"]/p/button/span")
	WebElement proceedToCheckoutShippingPage;
	
	@FindBy(css = "#HOOK_PAYMENT > div:nth-child(2) > div > p > a")
	WebElement chequePayment;
	
	@FindBy(xpath = "//*[@id='center_column']/form/div/h3")
	WebElement checkPaymentText;
	
	@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button")
	WebElement confirmOrder;
	
	@FindBy(css = "#center_column > p.alert.alert-success")
	WebElement orderCompleted;
	// Venkata's code for exam

	private MyStoreItemDescriptionPage(WebDriver _driver) {
		log.debug("creating Item Description PageObject");
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreItemDescriptionPage VerifyItemDescription(String _itemName) {
		log.debug("Verifying the description of the selected item on the page");
		String pageInformation = SeleniumHelper.GetInstance().GetDriver().getPageSource();
		if (pageInformation.contains(_itemName)) {
			log.info("The title " + _itemName + " was found successfully for the expected item");
		} else {
			log.error("The title " + _itemName + " was not found on the page");
		}
		return MyStoreItemDescriptionPage.GetInstance();
	}

	public MyStoreItemAddedToCartWindow AddItemToCart() {
		log.debug("Adding item displayed on the page in cart");
		Selenium.Click(addToCartButton);
		String expText = "Product successfully added to your shopping cart";
		if (SeleniumHelper.VerifyTextPresentOnPage(expText)) {
			log.info("The item was successfully added to the cart");
		} else {
			log.error("Failure to add the item to the cart");
		}
		return MyStoreItemAddedToCartWindow.GetInstance();
	}

	public MyStoreShoppingCartPage goToShoppingCart() {
		log.debug("Clicking the Cart link");
		Selenium.Click(cartLink);
		if (SeleniumHelper.VerifyItemExists(cartPageTitle)) {
			log.info("Successfully reached the Cart page");
		} else {
			log.error("Failure to get to the Cart page");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public MyStoreMyAccountPage goToMyAccountPage() {
		log.debug("Clicking the Customer Name link to navigate to the user account main page");
		Selenium.Click(customerNameLink);
		String expText = "Welcome to your account. Here you can manage all of your personal information and orders.";
		if (SeleniumHelper.VerifyTextPresentOnPage(expText)) {
			log.info("Successfully reached the My Account page");
		} else {
			log.error("Failure to get to the My Account page");
		}
		return MyStoreMyAccountPage.GetInstance();
	}

	public static MyStoreItemDescriptionPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreItemDescriptionPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public static void IamFinishHere() {
		System.out.println("******** I am Done Here ************* ");
	}
	
	
//////// Venkata's code for exam

	public void user_selectsBlueColor() {
		Selenium.Click(blueColorLink);
		System.out.println("******** user_selectsBlueColor ************* ");
		log.debug("user_ selects Blue Color-end");
		//String expText = "Welcome to your account. Here you can manage all of your personal information and orders.";
		}
	
	public void user_clicks_proceed_to_checkout_popup() {
		System.out.println("******** user clicks checkout ** ");
		Selenium.Click(checkoutButtonPopUp);
		System.out.println("******** user clicks checkout button pop-up ************* ");
	}
	
	public void user_verifies_printed_summer_dress_in_stock(String _itemStatus) {
		System.out.println("******** Expected*************: "+_itemStatus);
		Selenium.VerifyTextInElement(printedSummerDressInStock, _itemStatus);
		System.out.println("******** user_verifiesprintedSummerDressInStock************* "+_itemStatus);
		log.debug("Verifying item status in the cart");
	}
	
	public void user_verifies_faded_sleeve_tshirt_in_stock(String _tshirtStatus) {
		System.out.println("******** Expected*************: "+_tshirtStatus);
		Selenium.VerifyTextInElement(fadedshortsleevetshirtInStock, _tshirtStatus);
		System.out.println("******** user_verifies_faded_sleeve_tshirt_in_stock************* "+_tshirtStatus);
		log.debug("Verifying item status in the cart");
	}
	
	public void user_clicks_proceed_to_checkout_summary_page() {
		Selenium.Click(proceedToCheckoutSummaryPage);
		System.out.println("******** user clicks checkout button ************* ");
	}
	
	public void user_clicks_proceed_to_checkout_address_page() {
		Selenium.Click(proceedToCheckoutAddressPage);
		System.out.println("******** user clicks checkout button ************* ");
	}
	
	public void user_clicks_terms_of_service_checkbox() {
		Selenium.Click(checkBox);
		System.out.println("******** user clicks terms of service checkbox ************* ");
	}
	
	public void user_clicks_proceed_to_checkout_shipping_page() {
		Selenium.Click(proceedToCheckoutShippingPage);
		System.out.println("******** user clicks proceed to checkout ************* ");
	}
	
	public void user_clicks_pay_by_check() {
		Selenium.Click(chequePayment);
		System.out.println("******** user clicks cheque payment ************* ");
	}
	
	public void user_verifies_check_payment(String _checkPaymentDisplay) {
		Selenium.VerifyTextInElement(checkPaymentText, _checkPaymentDisplay);
		System.out.println("user verified check Payment is shown");
	}
	
	public void user_clicks_I_confirm_order() {
		Selenium.Click(confirmOrder);
		System.out.println("******** user clicks confirm order button ************* ");
	}
	
	public void user_verifies_order_completion(String _orderCompletion) {
		Selenium.VerifyTextInElement(orderCompleted, _orderCompletion);
		System.out.println("user verified order completion");
	}
}
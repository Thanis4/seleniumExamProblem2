package pageobjects;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStorePageObject extends PageObject {
	private static final Logger log = Logger.getLogger(MyStorePageObject.class);
	private static MyStorePageObject m_instance;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;
	@FindBy(id = "search_query_top")
	WebElement searchBox;
	@FindBy(name = "submit_search")
	WebElement searchButton;

	protected MyStorePageObject() {
// no PageTitle
	}

	protected MyStorePageObject(WebDriver _driver) {
// no PageTitle
		PageFactory.initElements(_driver, this);
	}

	public MyStoreSignInPage SignOut() {
		log.debug("Signing Out");
		Selenium.Click(signOutButton);
		SeleniumHelper.Seconds(1.2);
		return MyStoreSignInPage.GetInstance();
	}

	public static MyStorePageObject GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStorePageObject(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
package com.qaconsultants.learningmaven;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStoreOrderCheckOutPage;
import pageobjects.MyStoreSearchPage;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShoppingCartPage;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;

public class NewStepDefinition {
	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreMyAccountPage myAccountPage = MyStoreMyAccountPage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
	MyStoreSearchPage searchPage = MyStoreSearchPage.GetInstance();
	MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
	MyStoreItemAddedToCartWindow itemAddedToCartWindow = MyStoreItemAddedToCartWindow.GetInstance();
	MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
	MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
	MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
	MyStoreOrderCheckOutPage orderCheckOutPage = MyStoreOrderCheckOutPage.GetInstance();
	
	//PageObject pageObject = PageObject.GetInstance();
	
	@Given("^user navigates to homepage$")
	public void user_navigates_to_homepage() throws Exception
	{
	homePage.NavigateToThisPage();
	
	}

	@Then("^user verify My Store page title$")
	public void user_verify_my_store_page_title()
	{
		homePage.VerifyTitle();
		}

	@When("^user clicks Sign in button$")
	public void user_clicks_sign_in_button() {
		homePage.NavigateToSignInPage();
	}

	@When("^user verify Login - My Store page title$")
	public void user_verify_Login_My_Store_page_title () {
		signInPage.VerifyTitle();
	}

	@When ("^user Enter Email and Password$")
	public void user_Enter_Email_and_Password() {
		signInPage.SignIn();
	}
			
	@When ("^user searches for Printed Summer Dress$")
	public void user_searches_for_Printed_Summer_Dress ( ) {
		searchPage.SearchPrintedSummerDress();
		SeleniumHelper.Seconds(2);
		}
		
	/*@When("^user adds item to cart$")
	public void user_adds_item_to_cart()
	{
	itemDescriptionPage.AddItemToCart();
	SeleniumHelper.Seconds(2);
	}*/
			    
	@When ("^user verify Product successfully added to shopping cart message$")
	public void user_verify_Product_successfully_added_to_shopping_cart_message() {
		itemDescriptionPage.AddItemToCart();
		SeleniumHelper.Seconds(2);
	}
	
	@When ("^user continues shopping$")
	public void user_continues_shopping() {
		itemAddedToCartWindow.pressContinueShoppingButton();
		SeleniumHelper.Seconds(2);
	}
	
	@When ("^user searches for Faded Short Sleeve T-shirts$")
	public void Faded_Short_Sleeve_T_shirts( ) {
		
		searchPage.SearchFadedShortSleeveTshirts();
		SeleniumHelper.Seconds(2);
	}
	
	@When("^user select color options Blue$")
	public void user_select_color_options_Blue () {
	
		myAccountPage.selectColor("blueColor");
			}
	
	@When("^user adds item to cart$")
	public void user_adds_item_to_the_cart() {
		itemDescriptionPage.AddItemToCart();
         SeleniumHelper.Seconds(2);
                	}
	
	@When("user continues shopping1")
	public void user_continues_shopping1()
	{
	itemAddedToCartWindow.pressContinueShoppingButton();
	SeleniumHelper.Seconds(2);
	}
		
    @When("^user clicks shopping cart$")
	public void user_clicks_shopping_cart()
	{
	itemDescriptionPage.goToShoppingCart();
	SeleniumHelper.Seconds(2);
	 }
	
    @When("^user verify In stock for both products is in green$")
	public void user_verify_In_stock_for_both_products_in_green ( ) {
    	shoppingCartPage.VerifyItemPresenceInCart("In stock");
	}
		
   @When ("^user verify Printed Summer Dress is in cart$") 
	public void user_verify_Printed_Summer_Dress_is_in_cart ( ) {
	   orderCheckOutPage.VerifyItemPresenceInCart();
	}	
	
    @When ("^user verify Faded Short Sleeve T-shirts is in cart$") 
	public void user_verify_Faded_Short_Sleeve_T_shirts_is_in_cart ( ) {
    	orderCheckOutPage.VerifyItemPresenceInCart();
	}	
	
	@When("^user verify color is Blue$") 
	public void user_verify_color_is_Blue ( ) {
		shoppingCartPage.VerifyItemPresenceInCart("colorBlue");
	}
	
	@When("^user Click Proceed to Checkout Button$")
	public void user_Click_Proceed_to_Checkout_Button() {				
		shoppingCartPage.ProceedToCheckoutButton();
	}
	
		
@Then("^user verify page transition to Addresses section of checkout$")
	public void user_verify_page_transition_to_Addresses_section_of_checkout() {
		shoppingCartPage.VerifyTitle();
	}
	
@Then("^user verify page transition to Shipping section of checkout$") 
	public void user_verify_page_transition_to_Shipping_section_of_checkout() {
		shoppingCartPage.VerifyTitle();
		//shoppingCartPage.ProceedToCheckoutButton();
		SeleniumHelper.Seconds(2);
		}
@When("^user Click the Terms of Service checkbox$")
public void user_Click_the_Terms_of_Service_checkbox() {
	shoppingCartPage.ClickCheckBoxTS();
	SeleniumHelper.Seconds(3);
}

@Then("^user Click Proceed to Checkout Button1$")
public void user_Click_Proceed_to_Checkout_Button1() {				
	shoppingCartPage.ProceedToCheckoutButton();
}
	
@Then("^user verify page transition to Payment section of checkout$")
	public void user_verify_page_transition_to_Payment_section_of_checkout() {
	shoppingCartPage.VerifyTitle();
	}

@When("^user Click Pay By Check Button$") 
	public void user_Click_Pay_By_Check_Button() {
		shoppingCartPage.PayByCheque(); 
		SeleniumHelper.Seconds(2);
	}

@Then("^user verify that CHECK PAYMENT is displayed$")
	public void user_verify_that_CHECK_PAYMENT_is_displayed() {
	orderCheckOutPage.confirmChequePayment();
		
	}
	
@When("^user Click I Confirm My Order button$")
	public void user_Click_I_Confirm_My_Order_button() {
		shoppingCartPage.confirmMyOrderButton();
	}
	@Then ("^user verify Your order on My Store is complete is displayed$")
	public void user_verify_Your_order_on_My_Store_is_complete_is_displayed() {
		orderCheckOutPage.myStoreIsComplete();
			}
	
	@When("user Click Sign out")
	public void user_Click_Sign_out()
	{
		myAccountPage.SignOut();
	}
	@Then ("^user verify Login - My Store appears as title$")
	public void user_verify_Login_My_Store_appears_as_title() {
		signInPage.VerifyTitle();
	}
	}
	
	

	
	


package pageobjects;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import selenium.SeleniumHelper;
public abstract class PageObject
{
protected String m_pageTitle;
private static final Logger log = LogManager.getLogger(PageObject.class);
public void VerifyTitle() throws AssertionError
{
String actual = SeleniumHelper.GetTitle();
String expected = m_pageTitle;
Assert.assertEquals(actual, expected);
if (actual.equals(expected))
{
log.info("VerifyTitle: " + expected + " was equal to " + actual);
} else
{
log.error("VerifyTitle: " + expected + " was not equal to " + actual);
throw new AssertionError("VerifyTitle: " + expected + " was not equal to " + actual);
}
}
protected PageObject()
{
PageFactory.initElements(SeleniumHelper.GetInstance().GetDriver(), this);
}
public static PageObject GetInstance() {
	// TODO Auto-generated method stub
	return null;
}
}

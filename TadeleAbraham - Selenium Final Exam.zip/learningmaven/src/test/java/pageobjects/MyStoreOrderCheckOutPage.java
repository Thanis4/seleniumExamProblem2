package pageobjects;
import java.sql.Driver;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreOrderCheckOutPage extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreOrderCheckOutPage.class);
private static MyStoreOrderCheckOutPage m_instance;

//@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
//@FindBy(xpath = "//span[contains(text(), 'Proceed to checkout')]")
@FindBy(xpath ="(//body[@id='order']//span[contains(text(), 'Proceed to checkout')])[2]")
WebElement proceedToCheckoutButton;

@FindBy(xpath ="(//*[contains(text(), 'Check payment')])[2]")
WebElement checkPayment;

@FindBy(xpath ="//*[contains(text(), 'Printed Summer Dress')]")
WebElement PrintedSummerDressInStock;

@FindBy(xpath ="//*[contains(text(), 'Faded Short Sleeve')]")
WebElement FadedShortSleeveTeeInStock;

@FindBy(xpath ="//*[contains(text(), 'Blue')]")
WebElement colorBlue;

@FindBy(xpath = "(//span[contains(text(), 'In stock')])[1]")
WebElement inStock1;

@FindBy(xpath = "(//span[contains(text(), 'In stock')])[2]")
WebElement inStock2;

@FindBy(xpath = "//*[contains(text(), 'Your order on My Store is complete.')]")
WebElement orderConfirmationMsg;

private MyStoreOrderCheckOutPage(WebDriver _driver)
{
m_pageTitle = "Order - My Store";
PageFactory.initElements(_driver, this);
}
public MyStoreOrderCheckOutPage VerifyItemPresenceInCart(String _itemName)
{
log.debug("Verifying item presence in the cart");
if (SeleniumHelper.VerifyTextPresentOnPage(_itemName))
{
log.info("The item " + _itemName + " was successfully found in cart");
}
else
{
log.error("The item " + _itemName + " was NOT found in cart");
}
return MyStoreOrderCheckOutPage.GetInstance();
}
public static MyStoreOrderCheckOutPage GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStoreOrderCheckOutPage(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}

public MyStoreOrderCheckOutPage ProceedToCheckoutButton() {
	log.debug("Click the button Proceed to Check Out");
	Selenium.Click(proceedToCheckoutButton);
	return MyStoreOrderCheckOutPage.GetInstance();

}

public MyStoreOrderCheckOutPage confirmChequePayment () {
	log.debug("Confirm payment method before Check Out");
	Selenium.VerifyTextInElement(checkPayment, "CHECK PAYMENT");
	return MyStoreOrderCheckOutPage.GetInstance();
}
public MyStoreOrderCheckOutPage VerifyItemPresenceInCart() {
	log.debug("Confirm Printed Summer Dress is in cart");
	Selenium.VerifyTextInElement(inStock1, "In stock");
	return MyStoreOrderCheckOutPage.GetInstance();
	
}

public MyStoreOrderCheckOutPage VerifyItemPresenceInCart1() {
	log.debug("Confirm Faded Short Sleeve T-shirts is in cart");
	Selenium.VerifyTextInElement(inStock2, "In stock");
	return MyStoreOrderCheckOutPage.GetInstance();
}
public MyStoreOrderCheckOutPage myStoreIsComplete() {
	log.debug("Confirm Your order on My Store is complete");
	Selenium.VerifyTextInElement(orderConfirmationMsg, "Your order on My Store is complete.");
	return MyStoreOrderCheckOutPage.GetInstance();
	
}

}
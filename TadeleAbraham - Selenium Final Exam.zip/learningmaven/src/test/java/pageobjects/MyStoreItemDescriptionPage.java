package pageobjects;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;
public class MyStoreItemDescriptionPage extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreItemDescriptionPage.class);

private static MyStoreItemDescriptionPage m_instance;

@FindBy(xpath = "(//*[contains(text(),'Add to cart')])[1]")
WebElement addToCartButton;

@FindBy(xpath = "//a[@title = 'View my shopping cart']")
WebElement cartLink;

@FindBy(id = "cart_title")
WebElement cartPageTitle;

@FindBy(xpath = "//a[@title='View my customer account']")
WebElement customerNameLink;

@FindBy(xpath = "//*[@id='layer_cart']/div[1]/div[1]/span")
WebElement closeWindow;

//@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
@FindBy(xpath = "//span[contains(text(), 'Proceed to checkout')]")
WebElement ClickProceedToCheckoutButton;

private MyStoreItemDescriptionPage(WebDriver _driver)
{
log.debug("creating Item Description PageObject");
m_pageTitle = "My Store";
PageFactory.initElements(_driver, this);
}

public MyStoreItemDescriptionPage VerifyItemDescription(String _itemName)
{
log.debug("Verifying the description of the selected item on the page");
String pageInformation = SeleniumHelper.GetInstance().GetDriver().getPageSource();
if (pageInformation.contains(_itemName))
{
log.info("The title " + _itemName + " was found successfully for the expected item");
}
else
{
log.error("The title " + _itemName + " was not found on the page");
}
return MyStoreItemDescriptionPage.GetInstance();
}

public MyStoreItemAddedToCartWindow AddItemToCart()
{
log.debug("Adding item displayed on the page in cart");
Selenium.Click(addToCartButton);
String expText = "Product successfully added to your shopping cart";
if (SeleniumHelper.VerifyTextPresentOnPage(expText))
{
log.info("The item was successfully added to the cart");
}
else
{
log.error("Failure to add the item to the cart");
}
return MyStoreItemAddedToCartWindow.GetInstance();
}

public MyStoreShoppingCartPage goToShoppingCart()
{
log.debug("Clicking the Cart link");
Selenium.Click(cartLink);
if (SeleniumHelper.VerifyItemExists(cartPageTitle))
{
log.info("Successfully reached the Cart page");
}
else
{
log.error("Failure to get to the Cart page");
}
return MyStoreShoppingCartPage.GetInstance();
}

public MyStoreMyAccountPage goToMyAccountPage()
{
log.debug("Clicking the Customer Name link to navigate to the user account main page");
Selenium.Click(customerNameLink);
String expText = "Welcome to your account. Here you can manage all of your personal information and orders.";
if (SeleniumHelper.VerifyTextPresentOnPage(expText))
{
log.info("Successfully reached the My Account page");
}
else
{
log.error("Failure to get to the My Account page");
}
return MyStoreMyAccountPage.GetInstance();
}

public static MyStoreItemDescriptionPage GetInstance()
{
if (m_instance == null)
{
m_instance = new
MyStoreItemDescriptionPage(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}
}

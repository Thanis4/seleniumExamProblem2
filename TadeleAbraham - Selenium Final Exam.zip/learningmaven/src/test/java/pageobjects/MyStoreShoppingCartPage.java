package pageobjects;
import java.sql.Driver;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;



public class MyStoreShoppingCartPage extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
private static MyStoreShoppingCartPage m_instance;

//@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
//@FindBy(xpath = "//span[contains(text(), 'Proceed to checkout')]")
@FindBy(xpath ="(//body[@id='order']//span[contains(text(), 'Proceed to checkout')])[2]")
WebElement proceedToCheckoutButton;
 
@FindBy(id = "cgv")
WebElement selectCheckBox;

@FindBy(xpath = "//a[@class='cheque']")
WebElement payByCheque;

@FindBy(xpath ="//span[contains(text(), 'I confirm my order')]")
WebElement confirmOrder;

@FindBy(xpath ="//span[contains(text(), 'In stock')]")
WebElement inStock;

@FindBy(xpath ="//*[contains(text(), 'Printed Summer Dress')]")
WebElement PrintedSummerDressInstock;

@FindBy(xpath ="//*[contains(text(), 'Faded Short Sleeve')]")
WebElement FadedShortSleeveTee;

@FindBy(xpath ="//*[contains(text(), 'Blue')]")
WebElement colorBlue;

private MyStoreShoppingCartPage(WebDriver _driver)
{
m_pageTitle = "Order - My Store";
PageFactory.initElements(_driver, this);
}

/*public void MyStoreShoppingCartPage1(WebDriver _driver)
{
m_pageTitle = "Login - My Store";
PageFactory.initElements(_driver, this);
}*/

public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName)
{
log.debug("Verifying item presence in the cart");
if (SeleniumHelper.VerifyTextPresentOnPage(_itemName))
{
log.info("The item " + _itemName + " was successfully found in cart");
}
else
{
log.error("The item " + _itemName + " was NOT found in cart");
}
return MyStoreShoppingCartPage.GetInstance();
}
public static MyStoreShoppingCartPage GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}

public MyStoreShoppingCartPage ProceedToCheckoutButton() {
	log.debug("Click the button Proceed to Check Out");
	Selenium.Click(proceedToCheckoutButton);
	return MyStoreShoppingCartPage.GetInstance();

}
public MyStoreShoppingCartPage ClickCheckBoxTS() {
	log.debug("Click term and condition checkbox");
	//SeleniumHelper.ScrollElementIntoView(selectCheckBox);
	//Selenium.Click(selectCheckBox);  
	SeleniumHelper.CheckBox_JSExecutor(selectCheckBox);
	return MyStoreShoppingCartPage.GetInstance();
}
public MyStoreShoppingCartPage PayByCheque() {
	log.debug("Click PayByCheque button");
	Selenium.Click(payByCheque); 
	return MyStoreShoppingCartPage.GetInstance();
	
}
public MyStoreShoppingCartPage confirmMyOrderButton() {
	log.debug("Click confirm my order button");
	Selenium.Click(confirmOrder);
	return MyStoreShoppingCartPage.GetInstance();
	
}
}
package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCheckOutPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
	private static MyStoreCheckOutPage m_instance;
	
	@FindBy (xpath = "//*[@id=\"center_column\"]/p[2]/a[1]")
	WebElement proceedToCheck1;
	
	@FindBy (name = "processAddress") 
	WebElement proceedToCheck2;
	
	@FindBy (id = "cgv")
	WebElement termsOfService;
	
	@FindBy (name = "processCarrier")
	WebElement proceedToCheck3;
	
	
	private MyStoreCheckOutPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public MyStoreCheckOutPage ProceedToCheckOut1()
	{
		log.debug("Clicking on Proceed to Checkout button in Order Summary section");
		
		Selenium.Click(proceedToCheck1);
			
		return MyStoreCheckOutPage.GetInstance();
	}
	
	public MyStoreCheckOutPage ProceedToCheckOut2()
	{
		log.debug("Clicking on Proceed to Checkout button from Addresses section");
		
		Selenium.Click(proceedToCheck2);
			
		return MyStoreCheckOutPage.GetInstance();
	}
	
	public MyStoreCheckOutPage ProceedToCheckOut3()
	{
		log.debug("Clicking on Proceed to Checkout button from Shipping section");
		
		Selenium.Click(proceedToCheck3);
			
		return MyStoreCheckOutPage.GetInstance();
	}
	
	public MyStoreCheckOutPage VerifyAddressesSection()
	{
		log.debug("Verifying that page progresses to Addresses section");
		
		Boolean addressSectionPresent = SeleniumHelper.VerifyTextPresentOnPage("Addresses");
		
		if(addressSectionPresent)
			{
			  System.out.println("Page has progressed to Addresses section");
			  log.debug("Addresses section reached ");
			}
		else
			log.debug("Not proceeded to Address");
		return MyStoreCheckOutPage.GetInstance();
	}
	
	public MyStoreCheckOutPage clickTermsOfService()
	{
		
		log.debug("Accepting the Terms of service by selecting the checkbox ");	
		Selenium.Click(termsOfService);
		
		return MyStoreCheckOutPage.GetInstance();
		
	}
	
	public MyStoreCheckOutPage VerifyShippingSection()
	{
		log.debug("Verifying that page progresses to Shipping section");
		
		Boolean shippingSectionPresent = SeleniumHelper.VerifyTextPresentOnPage("Shipping");
		
		if(shippingSectionPresent)
			{
			  System.out.println("Page has progressed to Shipping section");
			  log.debug("Shipping section reached ");
			}
		else
			log.debug("Not proceeded to Shipping");
		return MyStoreCheckOutPage.GetInstance();
	}
	
	public MyStoreCheckOutPage VerifyPaymentSection()
	{
		log.debug("Verifying that page progresses to Payment section");
		
		Boolean paymentSectionPresent = SeleniumHelper.VerifyTextPresentOnPage("Your payment method");
				
		if(paymentSectionPresent)
		{
			System.out.println("Page has progressed to Payment section");
			 log.debug("Payment section reached ");
		}
		else
			log.debug("Not proceeded to Payment");
			
		return MyStoreCheckOutPage.GetInstance();
	}
	
	public MyStoreCheckOutPage PayByCheck()
	{
		
		
		return MyStoreCheckOutPage.GetInstance();
				
	}
	
	public static MyStoreCheckOutPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreCheckOutPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
	
	
	
	
}

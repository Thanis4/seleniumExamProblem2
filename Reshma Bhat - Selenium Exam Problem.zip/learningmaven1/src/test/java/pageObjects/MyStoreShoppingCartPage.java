package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
	private static MyStoreShoppingCartPage m_instance;
	
	@FindBy (id = "cart_summary")
	WebElement cartTable;
	
	private MyStoreShoppingCartPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName)
	{
		
		Boolean presence = SeleniumHelper.VerifyTextPresentOnPage(_itemName);
		
		if (presence)
			{
			  log.debug(_itemName + " has been added to cart");
			  System.out.println("The item " + _itemName + " is added to cart");
			}
		else
		   {
			log.debug(_itemName + " not found in cart");
		    System.out.println("The item " + _itemName + " is not available in the cart");
		   }
		
		return MyStoreShoppingCartPage.GetInstance();
		
	}
	
	public MyStoreShoppingCartPage VerifyItemInStock()
	{
		
		log.debug("Checking if items are in stock");
		
		//WebElement theFirstRow = cartTable.findElement(By.xpath("product_1_2_0_179382"));
		String fromAvailColumnFirstItem = SeleniumHelper.FindElement(By.xpath("//*[contains(@class,'cart_item first_item address')]/td[3]/span")).getText();
		//System.out.println(fromAvailColumnFirstItem);
		
		if(fromAvailColumnFirstItem.equalsIgnoreCase("In stock"))
			System.out.println("Printed Summer Dress is in stock");
		else
			System.out.println("Printed Summer Dress is not in stock");
		
		//WebElement theSecondRow = SeleniumHelper.FindElement(By.id("product_5_19_0_179382"));
		String fromAvailColumnSecondItem = SeleniumHelper.FindElement(By.xpath("//*[contains(@class,'cart_item last_item address')]/td[3]/span")).getText();
		//System.out.println(fromAvailColumnSecondItem);
		
		if(fromAvailColumnSecondItem.equalsIgnoreCase("In stock"))
			System.out.println("Faded Short Sleeve T-shirts is in stock");
		else
			System.out.println("Faded Short Sleeve T-shirts is not in stock");
		
		return MyStoreShoppingCartPage.GetInstance();
		
	}
	
	public static MyStoreShoppingCartPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}

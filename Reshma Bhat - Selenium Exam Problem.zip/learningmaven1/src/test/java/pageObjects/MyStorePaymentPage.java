package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStorePaymentPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
	private static MyStorePaymentPage m_instance;
	
	@FindBy (xpath = "//*[@id=\"HOOK_PAYMENT\"]/div[2]/div/p/a")  
	WebElement payByCheck;
	
	@FindBy (xpath = "//*[@id=\"cart_navigation\"]/button")
	WebElement confirmOrder;
	
	
	
	
	private MyStorePaymentPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public MyStorePaymentPage PayByCheck()
	{
		log.debug("Verifying that Pay by check button works correctly");
		
		Selenium.Click(payByCheck);
			
		return MyStorePaymentPage.GetInstance();
	}
	
	public MyStorePaymentPage VerifyCheckPayment()
	{
		log.debug("Verifying that Check Payment is displayed");
		
		Boolean checkPaymentPresent = SeleniumHelper.VerifyTextPresentOnPage("Check payment");
		
		if(checkPaymentPresent)
			{
			  System.out.println("Check Payment page is displayed");
			  log.debug("Check Payment reached ");
			}
		else
			log.debug("Not proceeded to Check Payment");
		
		return MyStorePaymentPage.GetInstance();
	}
	
	public MyStorePaymentPage ConfirmOrder()
	{
		log.debug("Verifying that Confirm Order works correctly");
		
		Selenium.Click(confirmOrder);
			
		return MyStorePaymentPage.GetInstance();
	}
	
	public MyStorePaymentPage VerifyOrderConfirmation()
	{
		log.debug("Verifying that order complete message is displayed");
		
		Boolean orderCompletePresent = SeleniumHelper.VerifyTextPresentOnPage("Your order on My Store is complete.");
		
		if(orderCompletePresent)
			{
			  System.out.println("Order completed");
			  log.debug("Order is complete ");
			}
		else
			log.debug("Order is not completed");
		
		return MyStorePaymentPage.GetInstance();
	}	
	public static MyStorePaymentPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStorePaymentPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
	
	
	
	
	
	
	
}

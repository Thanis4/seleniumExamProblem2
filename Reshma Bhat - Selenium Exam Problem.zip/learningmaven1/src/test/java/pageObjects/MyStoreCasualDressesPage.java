package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCasualDressesPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreCasualDressesPage.class);
	private static MyStoreCasualDressesPage m_instance;
	
	@FindBy(linkText = "Casual Dresses")
	WebElement casualdressesHeader;
	
	private MyStoreCasualDressesPage(WebDriver _driver)
	{
	   m_pageTitle = "Casual Dresses";
	   PageFactory.initElements(_driver, this);
	}
	
	public MyStoreCasualDressesPage VerifyCasualDressesHeader()
	{
		SeleniumHelper.VerifyPageTitle("Casual Dresses - My Store");
	//Selenium.VerifyTextInElement(casualdressesHeader, "Casual Dresses");
	return MyStoreCasualDressesPage.GetInstance();
	}
	
	public MyStoreCasualDressesPage NavigateToCasualDressesPage()
	{
	log.debug("navigating to Casual Dresses page");
	Selenium.Click(casualdressesHeader);
	SeleniumHelper.Seconds(2);
	return MyStoreCasualDressesPage.GetInstance();
	}
	
	public static MyStoreCasualDressesPage GetInstance()
	{
	if (m_instance == null)
	{
	m_instance = new MyStoreCasualDressesPage(SeleniumHelper.GetInstance().GetDriver());
	}
	return m_instance;
	}
	
}

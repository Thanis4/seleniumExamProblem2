package com.qac.tdseleniumtwo;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.MyStoreContactUsPage;
import pageObjects.MyStoreCreateAnAccountPage;
import pageObjects.MyStoreHomePage;
import pageObjects.MyStoreItemAddedToCartWindow;
import pageObjects.MyStoreItemDescriptionPage;
import pageObjects.MyStoreMyAccountPage;
import pageObjects.MyStorePageObject;
import pageObjects.MyStorePaymentPage;
import pageObjects.MyStoreSearchResultsPage;
import pageObjects.MyStoreShoppingCartPage;
import pageObjects.MyStoreSignInPage;
import selenium.SeleniumHelper;
import pageObjects.MyStoreDressesPage;
import pageObjects.MyStoreCasualDressesPage;
import pageObjects.MyStoreCheckOutPage;

public class StepDefs
{
MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
MyStoreMyAccountPage myAccountPage = MyStoreMyAccountPage.GetInstance();
MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
MyStoreDressesPage dressesPage = MyStoreDressesPage.GetInstance();
MyStoreCasualDressesPage casualdressesPage = MyStoreCasualDressesPage.GetInstance();
MyStoreItemAddedToCartWindow cartItem = MyStoreItemAddedToCartWindow.GetInstance();
MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
MyStoreCheckOutPage checkOutPage = MyStoreCheckOutPage.GetInstance();
MyStorePaymentPage paymentPage = MyStorePaymentPage.GetInstance();


@Given("^user is on homepage$")
public void user_is_on_homepage() throws Exception
{
homePage.NavigateToThisPage();
}
@When("^user navigates to signinpage$")
public void user_navigates_to_signinpage()
{
homePage.NavigateToSignInPage();
}
@When("user begins registration")
public void user_begins_registration()
{
signInPage.CreateAnAccount();
}
@When("user enters default data")
public void user_enters_default_data()
{
createAccountPage.EnterAccountDetails();
}
@When("user logs out")
public void user_logs_out()
{
myAccountPage.SignOut();
}
@Then("verify signinpage title")
public void verify_signinpage_title()
{
signInPage.VerifyTitle();
}
@When("user signs in")
public void user_signs_in()
{
signInPage.SignIn();
}
@Then("verify myaccountpage title")
public void verify_myaccountpage_title()
{
myAccountPage.VerifyTitle();
}
@When("user navigates to contactuspage")
public void user_navigates_to_contactuspage()
{
myAccountPage.NavigateToContactUsPage();
}
@Then("verify contactuspage title")
public void verify_contactuspage_title()
{
contactUsPage.VerifyTitle();
}

@When("user navigates to Dresses")
public void user_navigates_to_dressespage()
{
   dressesPage.NavigateToDressesPage();
}
@Then("verify dressespage title")
public void verify_dressespage_title()
{
   dressesPage.VerifyDressesHeader();
}
@When("user navigates to Casual Dresses")
public void user_navigates_to_casualdressespage()
{
	casualdressesPage.NavigateToCasualDressesPage();
}
@Then("verify casualdressespage title")
public void verify_casualdressespage_title()
{
	casualdressesPage.VerifyCasualDressesHeader();
}

@When("user searches for {string}")
public void user_searches_for(String string) 
   {
	searchResultsPage.SearchForItem(string);
	searchResultsPage.SelectItem(string);
	 
   }

@When("user clicks on Add to cart button")
public void user_clicks_on_Add_to_cart_button()
   {
	itemDescriptionPage.AddItemToCart();
	SeleniumHelper.Seconds(3);
    
   }

@When("user clicks on Continue shopping")
public void user_clicks_on_Continue_shopping()
   {
	cartItem.pressContinueShoppingButton();	
    
   }

@When("user clicks on Cart button")
public void user_clicks_on_Cart_button() 
   {
	itemDescriptionPage.goToShoppingCart();
    
   }

@Then("verify {string} is in cart")
public void verify_added_item_in_cart(String string) 
   {
	shoppingCartPage.VerifyItemPresenceInCart(string);
	SeleniumHelper.Seconds(1);
   }

@When("user selects Blue color")
public void user_selects_Blue_color() 
  {
    searchResultsPage.SelectBlueColor();
    SeleniumHelper.Seconds(1);
  }

@Then("verify both items shows In Stock")
public void verify_shows_In_Stock() 
  {
    shoppingCartPage.VerifyItemInStock();
  }

@When("user clicks on Proceed to Checkout first time")
public void user_clicks_on_Proceed_to_Checkout_first_time() 
  {
    checkOutPage.ProceedToCheckOut1();
  }

@Then("verify page transitions to Addresses section")
public void verify_page_transitions_to_Addresses_section() 
  {
    checkOutPage.VerifyAddressesSection();
  }

@When("user clicks on Proceed to Checkout second time")
public void user_clicks_on_Proceed_to_Checkout_second_time() 
  {
    checkOutPage.ProceedToCheckOut2();
  }

@Then("verify page transitions to Shipping section")
public void verify_page_transitions_to_Shipping_section() 
  {
    checkOutPage.VerifyShippingSection();
  }

@When("user selects checkbox for Terms of service")
public void user_selects_checkbox_for_Terms_of_service() 
  {
    checkOutPage.clickTermsOfService();
  }

@When("user clicks on Proceed to Checkout third time")
public void user_clicks_on_Proceed_to_Checkout_third_time() 
  {
    checkOutPage.ProceedToCheckOut3();
  }

@Then("verify page transitions to Payment section")
public void verify_page_transitions_to_Payment_section() 
  {
    checkOutPage.VerifyPaymentSection();
  }

@When("user clicks on Pay by check button")
public void user_clicks_on_Pay_by_check_button() 
  {
	paymentPage.PayByCheck();
  }

@Then("verify that Check Payment is displayed")
public void verify_that_Check_Payment_is_displayed() 
  {
	paymentPage.VerifyCheckPayment();
  }

@When("user clicks on I confirm my order button")
public void user_clicks_on_I_confirm_my_order_button() 
  {
    paymentPage.ConfirmOrder();
  }

@Then("verify order is complete message")
public void verify_order_is_complete_message() 
  {
    paymentPage.VerifyOrderConfirmation();
  }

@Then("sign out")
public void sign_out() 
   {
     MyStorePageObject.GetInstance().SignOut();
	
   }

}


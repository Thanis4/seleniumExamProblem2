package selenium;

import org.testng.annotations.Test;

import selenium.SeleniumHelper;
import org.openqa.selenium.WebDriver;

public class NewTest {
  @Test
  public void f() {
	  
	  SeleniumHelper sh = SeleniumHelper.GetInstance();
      WebDriver driver = sh.GetDriver();
      driver.get("http://www.google.ca");
      
            
      SeleniumHelper.Seconds(5);
      
      sh.CloseDriver();
	  
	  
  }
}




package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreSearchResultPage {

	private static final Logger log = LogManager.getLogger(MyStoreSearchResultPage.class);
	private static MyStoreSearchResultPage m_instance;
	

	@FindBy(xpath = "//*[@id=\"center_column\"]/h1/span[2]")
	WebElement headingcounter;
	

	private MyStoreSearchResultPage(WebDriver _driver) {
		PageFactory.initElements(_driver, this);
	}
	
	public MyStoreSearchResultPage VerifyTestResultValues() {
		Selenium.VerifyTextInElement(headingcounter, "3 results have been found.");
		return MyStoreSearchResultPage.GetInstance();
	}
	
	
	public static MyStoreSearchResultPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreSearchResultPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
	
	
	public MyStoreItemDescriptionPage SelectItem(String _itemName) {
		log.debug("Selecting item");
		WebElement itemToBeSelected = SeleniumHelper.FindElement(By.linkText(_itemName));
		if (itemToBeSelected.isDisplayed()) {
			itemToBeSelected.click();
			if (SeleniumHelper.VerifyPageTitle(_itemName)) {
				log.info("Successfully selected the item " + _itemName);
			} else {
				log.error("Failed to select the item " + _itemName);
			}
		} else {
			log.error("The searched item was not found");
		}
		return MyStoreItemDescriptionPage.GetInstance();
	}
}

package LearningSelenium.Practice_Maven;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import selenium.SeleniumHelper;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/feature_files")
public class RunCucumberTest {

	@AfterClass
	public static void TearDown()
	{
		SeleniumHelper.GetInstance().CloseDriver();
	}

}
